const BASE_URL = 'https://project-dle5b.vercel.app'

// ── Message listener ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'PING') {
    sendResponse({ ok: true })
    return true
  }
  if (msg.type === 'POST_LISTING') {
    handlePost(msg.listing, msg.platforms)
      .then(() => sendResponse({ ok: true }))
      .catch(e => sendResponse({ ok: false, error: e.message }))
    return true
  }
  if (msg.type === 'VINTED_SYNC_DATA') {
    importVintedHistory(msg.data, sender.tab?.id)
    sendResponse({ ok: true })
    return true
  }
  if (msg.type === 'IMPORT_VINTED_LISTING') {
    importVintedListing(msg.listing)
      .then(result => sendResponse({ ok: true, result }))
      .catch(e => sendResponse({ ok: false, error: e.message }))
    return true
  }
  if (msg.type === 'INJECT_MAIN_IMAGES') {
    const tabId = sender.tab?.id
    if (!tabId) { sendResponse({ ok: false, error: 'Kein Tab' }); return true }
    chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: injectImages,
      args: [msg.imageData],
    }).then(() => sendResponse({ ok: true }))
      .catch(e => sendResponse({ ok: false, error: e.message }))
    return true
  }
})

// ── Image loader ──────────────────────────────────────────────────────────────

async function fetchImageAsBase64(url) {
  try {
    const res  = await fetch(url)
    if (!res.ok) return null
    const blob = await res.blob()
    return await new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload  = () => resolve({ base64: reader.result, type: blob.type || 'image/jpeg' })
      reader.onerror = reject
      reader.readAsDataURL(blob)
    })
  } catch { return null }
}

// ── Post listing to platforms ─────────────────────────────────────────────────

async function handlePost(listing, platforms) {
  // Load images as base64 (max 8)
  const imageData = []
  for (const url of (listing.images || []).slice(0, 8)) {
    const fullUrl = url.startsWith('http') ? url : `${BASE_URL}${url}`
    const data = await fetchImageAsBase64(fullUrl)
    if (data) imageData.push(data)
  }

  const fullListing = { ...listing, imageData }
  await chrome.storage.local.set({ pendingListing: fullListing })
  console.log('[ListSync BG] Bilder geladen:', imageData.length, '– ID:', listing.id)

  for (const platform of platforms) {
    if (platform === 'vinted') {
      await openVintedNewListing(imageData)
    }
    if (platform === 'kleinanzeigen') {
      await openKleinanzeigenNewListing()
    }
    if (platform === 'ebay') {
      await openEbayNewListing()
    }
  }
}

async function openKleinanzeigenNewListing() {
  await chrome.tabs.create({ url: 'https://www.kleinanzeigen.de/anzeige/aufgeben' })
  console.log('[ListSync BG] ✓ Kleinanzeigen-Tab geöffnet')
}

async function openEbayNewListing() {
  await chrome.tabs.create({ url: 'https://www.ebay.de/sl/list' })
  console.log('[ListSync BG] ✓ eBay-Tab geöffnet')
}

async function openVintedNewListing(imageData) {
  const { activeVintedAccount } = await chrome.storage.local.get('activeVintedAccount')

  // vinted.js content script übernimmt Formular + Bild-Injection
  // (liest pendingListing inkl. imageData direkt aus chrome.storage)
  await chrome.tabs.create({ url: 'https://www.vinted.de/items/new' })
  console.log('[ListSync BG] ✓ Vinted-Tab geöffnet')
}

// ── Vinted history import ─────────────────────────────────────────────────────

async function importVintedHistory(data, sourceTabId) {
  try {
    const { token } = await chrome.storage.local.get('authToken')
    const res = await fetch(`${BASE_URL}/api/import`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body:    JSON.stringify(data),
      credentials: 'include',
    })
    const result = await res.json()
    console.log('[ListSync BG] Import:', result)
    // Notify popup
    chrome.runtime.sendMessage({ type: 'IMPORT_DONE', result }).catch(() => {})
  } catch(e) {
    console.warn('[ListSync BG] Import fehlgeschlagen:', e.message)
  }
}

// ── Vinted Listing importieren (von Artikel-Detailseite) ─────────────────────

async function importVintedListing(listing) {
  try {
    // Bilder als Base64 laden (für späteren Upload zu ListSync)
    const uploadedImages = []
    for (const url of (listing.images || []).slice(0, 8)) {
      try {
        // Vinted-Bilder direkt über Fetch laden (background hat host_permissions)
        const res = await fetch(url)
        if (!res.ok) continue
        const blob = await res.blob()
        // Als FormData an ListSync Upload-API schicken
        const fd = new FormData()
        const ext = (blob.type || 'image/jpeg').split('/')[1] || 'jpg'
        fd.append('files', new File([blob], `import_${uploadedImages.length + 1}.${ext}`, { type: blob.type }))
        const uploadRes = await fetch(`${BASE_URL}/api/upload`, {
          method: 'POST',
          body: fd,
          credentials: 'include',
        })
        if (uploadRes.ok) {
          const { urls } = await uploadRes.json()
          if (urls?.[0]) uploadedImages.push(urls[0])
        }
      } catch(e) {
        console.warn('[ListSync BG] Bild-Upload fehlgeschlagen:', e.message)
      }
    }

    // Listing in ListSync erstellen
    const body = {
      title:       listing.title || 'Vinted-Import',
      description: listing.description || '',
      price:       listing.price || 0,
      buyPrice:    0,
      category:    listing.category || 'Sonstiges',
      condition:   listing.condition || '',
      brand:       listing.brand || '',
      size:        listing.size || '',
      color:       listing.color || '',
      images:      uploadedImages,
      platforms:   ['vinted'],
      shipping:    [],
      shipSize:    '',
      status:      'aktiv',
    }

    const res = await fetch(`${BASE_URL}/api/listings`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body),
      credentials: 'include',
    })

    if (!res.ok) throw new Error('API Fehler: ' + res.status)
    const result = await res.json()
    console.log('[ListSync BG] ✅ Vinted-Listing importiert:', result.id)
    return result
  } catch(e) {
    console.warn('[ListSync BG] Import-Fehler:', e.message)
    throw e
  }
}

// ── Image injection (runs in MAIN world) ──────────────────────────────────────
// This function is serialized and injected into the page – no closures!

function injectImages(imageData) {
  if (!imageData?.length) { console.warn('[ListSync MAIN] Keine Bilder'); return }

  function b64ToFile(img, i) {
    const [, d] = img.base64.split(',')
    const bin = atob(d)
    const arr = new Uint8Array(bin.length)
    for (let j = 0; j < bin.length; j++) arr[j] = bin.charCodeAt(j)
    const ext = (img.type || 'image/jpeg').split('/')[1] || 'jpg'
    return new File([arr], `listsync_${i + 1}.${ext}`, { type: img.type || 'image/jpeg' })
  }

  const files = imageData.map((img, i) => b64ToFile(img, i))
  const dt = new DataTransfer()
  files.forEach(f => dt.items.add(f))

  // Strategy 1: Find file input, use React Fiber
  const inputSelectors = [
    'input[type="file"][accept*="image"]',
    'input[type="file"][name*="photo"]',
    'input[type="file"][name*="image"]',
    'input[type="file"][multiple]',
    'input[type="file"]',
  ]
  let fi = null
  for (const sel of inputSelectors) {
    fi = document.querySelector(sel)
    if (fi) break
  }

  if (fi) {
    Object.defineProperty(fi, 'files', { get: () => dt.files, configurable: true })

    // Try React Fiber first (most reliable for React apps)
    const fk = Object.keys(fi).find(k =>
      k.startsWith('__reactFiber') ||
      k.startsWith('__reactInternals') ||
      k.startsWith('__reactEventHandlers') ||
      k.startsWith('__reactProps')
    )
    if (fk) {
      let node = fi[fk]
      while (node) {
        const handler = node?.memoizedProps?.onChange || node?.pendingProps?.onChange
        if (handler) {
          try {
            handler({
              target: fi, currentTarget: fi,
              preventDefault: () => {}, stopPropagation: () => {},
              persist: () => {}, nativeEvent: new Event('change', { bubbles: true })
            })
            console.log('[ListSync MAIN] ✓ React Fiber –', files.length, 'Bilder')
            return
          } catch(e) { console.warn('[ListSync MAIN] Fiber-Fehler:', e.message) }
        }
        node = node.return
      }
    }

    // Fallback: native events
    fi.dispatchEvent(new Event('change', { bubbles: true }))
    fi.dispatchEvent(new Event('input',  { bubbles: true }))
    console.log('[ListSync MAIN] ✓ Native Events –', files.length, 'Bilder')
    return
  }

  // Strategy 2: Drop zone
  const dropSelectors = [
    '[data-testid*="photo-upload"]',
    '[data-testid*="upload"]',
    '[class*="photo-upload"]',
    '[class*="upload-zone"]',
    '[class*="dropzone"]',
    '[class*="drop-zone"]',
    '[class*="UploadZone"]',
    '[class*="PhotoUpload"]',
  ]
  for (const sel of dropSelectors) {
    const zone = document.querySelector(sel)
    if (zone) {
      zone.dispatchEvent(new DragEvent('dragenter', { bubbles: true, cancelable: true, dataTransfer: dt }))
      zone.dispatchEvent(new DragEvent('dragover',  { bubbles: true, cancelable: true, dataTransfer: dt }))
      zone.dispatchEvent(new DragEvent('drop',      { bubbles: true, cancelable: true, dataTransfer: dt }))
      console.log('[ListSync MAIN] ✓ Drop-Event auf', sel)
      return
    }
  }

  console.warn('[ListSync MAIN] Kein Upload-Element gefunden')
}
