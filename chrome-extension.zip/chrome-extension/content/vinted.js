'use strict'

// ── Helpers ───────────────────────────────────────────────────────────────────

async function getListing() {
  return new Promise(resolve =>
    chrome.storage.local.get('pendingListing', r => resolve(r.pendingListing || null))
  )
}

const wait = ms => new Promise(r => setTimeout(r, ms))

function setNativeValue(el, value) {
  const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set
  if (setter) setter.call(el, value)
  else el.value = value
  el.dispatchEvent(new Event('input',  { bubbles: true }))
  el.dispatchEvent(new Event('change', { bubbles: true }))
  el.dispatchEvent(new Event('blur',   { bubbles: true }))
}

function waitFor(selectors, timeout = 15000) {
  const sels = Array.isArray(selectors) ? selectors : [selectors]
  return new Promise((resolve, reject) => {
    const find = () => {
      for (const s of sels) {
        try { const el = document.querySelector(s); if (el) return el } catch {}
      }
      return null
    }
    const found = find()
    if (found) return resolve(found)
    const ob = new MutationObserver(() => {
      const el = find()
      if (el) { ob.disconnect(); clearTimeout(tid); resolve(el) }
    })
    ob.observe(document.body, { childList: true, subtree: true, attributes: true })
    const tid = setTimeout(() => { ob.disconnect(); reject(new Error('Timeout: ' + sels[0])) }, timeout)
  })
}

// Find input by nearby label text (fallback)
function findByLabel(text) {
  for (const l of document.querySelectorAll('label')) {
    if (l.textContent.toLowerCase().includes(text.toLowerCase())) {
      if (l.htmlFor) { const el = document.getElementById(l.htmlFor); if (el) return el }
      const el = l.querySelector('input, textarea') || l.parentElement?.querySelector('input, textarea')
      if (el) return el
    }
  }
  return null
}

// ── Banner ────────────────────────────────────────────────────────────────────

function showBanner(listing, accountName) {
  if (document.getElementById('ls-banner')) return
  const d = document.createElement('div')
  d.id = 'ls-banner'
  d.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#4f46e5;color:#fff;font-family:sans-serif;padding:10px 16px;display:flex;align-items:center;gap:10px;box-shadow:0 3px 16px rgba(0,0,0,.4)'
  d.innerHTML = `
    <span style="font-size:20px">🔗</span>
    <div style="flex:1;min-width:0">
      <div style="font-weight:700;font-size:13px">ListSync${accountName ? ' · ' + accountName : ''}</div>
      <div id="ls-status" style="font-size:11px;opacity:.8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${listing.title} · ${listing.price} €</div>
    </div>
    <button onclick="document.getElementById('ls-banner').remove();document.body.style.paddingTop=''"
      style="background:rgba(255,255,255,.2);border:none;color:#fff;border-radius:7px;padding:5px 10px;cursor:pointer;font-size:12px;font-weight:600">✕</button>
  `
  document.body.prepend(d)
  document.body.style.paddingTop = '54px'
}

function setStatus(msg, done = false) {
  const el = document.getElementById('ls-status')
  if (el) el.textContent = msg
  if (done) {
    const b = document.getElementById('ls-banner')
    if (b) b.style.background = '#16a34a'
  }
  console.log('[ListSync]', msg)
}

// ── Fill helpers ──────────────────────────────────────────────────────────────

async function fillField(selectors, value, labelHint, name) {
  if (value === undefined || value === null || value === '') return false
  try {
    let el = null
    try { el = await waitFor(selectors, 7000) } catch {}
    if (!el && labelHint) el = findByLabel(labelHint)
    if (!el) { console.warn('[ListSync] Nicht gefunden:', name); return false }

    el.scrollIntoView({ behavior: 'smooth', block: 'center' })
    await wait(200)
    el.focus()
    await wait(100)
    setNativeValue(el, String(value))
    await wait(200)
    // Retry once if value didn't stick
    if (el.value !== String(value)) {
      el.focus(); setNativeValue(el, String(value)); await wait(200)
    }
    setStatus('✓ ' + name)
    return true
  } catch(e) {
    console.warn('[ListSync] Fehler bei', name, e.message)
    return false
  }
}

async function fillAutocomplete(selectors, value, labelHint, name) {
  if (!value) return false
  try {
    let el = null
    try { el = await waitFor(selectors, 7000) } catch {}
    if (!el && labelHint) el = findByLabel(labelHint)
    if (!el) { console.warn('[ListSync] Nicht gefunden:', name); return false }

    el.scrollIntoView({ behavior: 'smooth', block: 'center' })
    await wait(200)
    el.focus()
    setNativeValue(el, value)
    await wait(1200) // wait for dropdown to appear

    // Click first visible option
    const optSels = [
      '[role="option"]:not([aria-disabled="true"])',
      '[class*="suggestion"] li:first-child',
      '[class*="autocomplete"] li:first-child',
      '[class*="dropdown"] [role="option"]:first-child',
      '[class*="Dropdown"] li:first-child',
    ]
    for (const s of optSels) {
      const opt = document.querySelector(s)
      if (opt && opt.offsetParent !== null) { reactClick(opt); await wait(400); break }
    }
    setStatus('✓ ' + name)
    return true
  } catch(e) {
    console.warn('[ListSync] Autocomplete Fehler:', name, e.message)
    return false
  }
}

// ── Legacy-Hilfsfunktionen ────────────────────────────────────────────────────

const CATEGORY_MAP = {
  // ── Damen ──────────────────────────────────────────────────────────────
  'Damen – Kleidung':                         ['Damen', 'Kleidung'],
  'Damen – Kleidung – Jacken & Mäntel':       ['Damen', 'Kleidung', 'Jacken & Mäntel'],
  'Damen – Kleidung – Kleider':               ['Damen', 'Kleidung', 'Kleider'],
  'Damen – Kleidung – Röcke':                 ['Damen', 'Kleidung', 'Röcke'],
  'Damen – Kleidung – Tops & T-Shirts':       ['Damen', 'Kleidung', 'Tops & T-Shirts'],
  'Damen – Kleidung – Hosen & Jeans':         ['Damen', 'Kleidung', 'Hosen'],
  'Damen – Kleidung – Pullover & Strickpullover': ['Damen', 'Kleidung', 'Pullover & Strickpullover'],
  'Damen – Kleidung – Blazer & Anzüge':       ['Damen', 'Kleidung', 'Blazer & Anzüge'],
  'Damen – Kleidung – Shorts':                ['Damen', 'Kleidung', 'Shorts'],
  'Damen – Kleidung – Unterwäsche & Socken':  ['Damen', 'Kleidung', 'Unterwäsche & Socken'],
  'Damen – Kleidung – Sportkleidung':         ['Damen', 'Kleidung', 'Sportkleidung'],
  'Damen – Schuhe':                           ['Damen', 'Schuhe'],
  'Damen – Taschen':                          ['Damen', 'Taschen'],
  'Damen – Accessoires':                      ['Damen', 'Accessoires'],
  'Damen – Beauty':                           ['Damen', 'Beauty'],
  // ── Herren ─────────────────────────────────────────────────────────────
  'Herren – Kleidung':                        ['Herren', 'Kleidung'],
  'Herren – Kleidung – Jeans':                ['Herren', 'Kleidung', 'Jeans'],
  'Herren – Kleidung – Jacken & Mäntel':      ['Herren', 'Kleidung', 'Jacken & Mäntel'],
  'Herren – Kleidung – Tops & T-Shirts':      ['Herren', 'Kleidung', 'Tops & T-Shirts'],
  'Herren – Kleidung – Pullover & Sweater':   ['Herren', 'Kleidung', 'Pullover & Sweater'],
  'Herren – Kleidung – Hosen':                ['Herren', 'Kleidung', 'Hosen'],
  'Herren – Kleidung – Shorts':               ['Herren', 'Kleidung', 'Shorts'],
  'Herren – Kleidung – Anzüge & Blazer':      ['Herren', 'Kleidung', 'Anzüge & Blazer'],
  'Herren – Kleidung – Unterwäsche & Socken': ['Herren', 'Kleidung', 'Unterwäsche & Socken'],
  'Herren – Kleidung – Sportkleidung':        ['Herren', 'Kleidung', 'Sportartikel'],
  'Herren – Schuhe':                          ['Herren', 'Schuhe'],
  'Herren – Accessoires':                     ['Herren', 'Accessoires'],
  // ── Kinder ─────────────────────────────────────────────────────────────
  'Kinder – Mädchen':                         ['Kinder', 'Mädchen'],
  'Kinder – Mädchen – Kleider':               ['Kinder', 'Mädchen', 'Kleider'],
  'Kinder – Mädchen – Jacken & Mäntel':       ['Kinder', 'Mädchen', 'Outerwear'],
  'Kinder – Mädchen – Shirts & Tops':         ['Kinder', 'Mädchen', 'Shirts, Tops & Blusen'],
  'Kinder – Mädchen – Hosen & Shorts':        ['Kinder', 'Mädchen', 'Hosen & Shorts'],
  'Kinder – Mädchen – Schuhe':                ['Kinder', 'Mädchen', 'Schuhe'],
  'Kinder – Mädchen – Sportkleidung':         ['Kinder', 'Mädchen', 'Sportkleidung'],
  'Kinder – Jungs':                           ['Kinder', 'Jungs'],
  'Kinder – Jungs – Jacken & Mäntel':         ['Kinder', 'Jungs', 'Outerwear'],
  'Kinder – Jungs – Shirts & Tops':           ['Kinder', 'Jungs', 'Shirts & Tops'],
  'Kinder – Jungs – Hosen & Shorts':          ['Kinder', 'Jungs', 'Hosen & Shorts'],
  'Kinder – Jungs – Schuhe':                  ['Kinder', 'Jungs', 'Schuhe'],
  'Kinder – Jungs – Sportkleidung':           ['Kinder', 'Jungs', 'Sportkleidung'],
  'Kinder – Spielzeug':                       ['Kinder', 'Spielzeug'],
  // ── Sonstiges ──────────────────────────────────────────────────────────
  'Elektronik':                               ['Elektronik'],
  'Home & Living':                            ['Home'],
  'Sport & Outdoor':                          ['Sport'],
  'Unterhaltung':                             ['Unterhaltung'],
  'Sonstiges':                                [],
}

// ── React-bewusstes Klicken ───────────────────────────────────────────────────
// Vollständige Pointer+Mouse Event-Kette PLUS React-Fiber onClick-Aufruf.
// Nötig weil Vinted React-18 Event-Delegation nutzt – .click() reicht nicht.
function fullClick(el) {
  if (!el) return
  el.dispatchEvent(new PointerEvent('pointerover',  { bubbles: true, cancelable: true }))
  el.dispatchEvent(new PointerEvent('pointerenter', { bubbles: true, cancelable: true }))
  el.dispatchEvent(new PointerEvent('pointerdown',  { bubbles: true, cancelable: true }))
  el.dispatchEvent(new MouseEvent('mousedown',      { bubbles: true, cancelable: true }))
  el.dispatchEvent(new PointerEvent('pointerup',    { bubbles: true, cancelable: true }))
  el.dispatchEvent(new MouseEvent('mouseup',        { bubbles: true, cancelable: true }))
  el.dispatchEvent(new MouseEvent('click',          { bubbles: true, cancelable: true }))
  reactClick(el)
}

// Geht durch Reacts internen Fiber-Baum und ruft onClick direkt auf.
// Viel zuverlässiger als el.click() bei React-18-Apps (Vinted).
function reactClick(el) {
  // React speichert den Fiber unter __reactFiber$xxx oder __reactInternalInstance$xxx
  const fiberKey = Object.keys(el).find(k =>
    k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance')
  )
  if (fiberKey) {
    let fiber = el[fiberKey]
    // Nach oben durch den Fiber-Baum suchen bis wir ein onClick finden
    let tries = 0
    while (fiber && tries++ < 20) {
      const props = fiber.memoizedProps || fiber.pendingProps
      if (props && typeof props.onClick === 'function') {
        try {
          props.onClick({
            target: el,
            currentTarget: el,
            type: 'click',
            bubbles: true,
            preventDefault: () => {},
            stopPropagation: () => {},
            nativeEvent: new MouseEvent('click', { bubbles: true }),
          })
          return true
        } catch(e) { console.warn('[ListSync] reactClick Fehler:', e) }
      }
      fiber = fiber.return
    }
  }
  // Fallback: normaler Browser-Klick mit vollständigen MouseEvents
  el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true, cancelable: true }))
  el.dispatchEvent(new MouseEvent('mouseover',  { bubbles: true, cancelable: true }))
  el.dispatchEvent(new MouseEvent('mousedown',  { bubbles: true, cancelable: true }))
  el.dispatchEvent(new MouseEvent('mouseup',    { bubbles: true, cancelable: true }))
  el.dispatchEvent(new MouseEvent('click',      { bubbles: true, cancelable: true }))
  return false
}

async function clickOption(text) {
  // Sucht sichtbare Option mit passendem Text und klickt sie (React-aware)
  const sels = [
    '[role="option"]', '[role="menuitem"]', '[role="listitem"]',
    'li', 'button', '[class*="item"]', '[class*="option"]',
  ]
  for (const s of sels) {
    for (const el of document.querySelectorAll(s)) {
      if (el.offsetParent !== null && el.textContent.trim().toLowerCase().includes(text.toLowerCase())) {
        await wait(100)
        reactClick(el)
        await wait(800)
        return true
      }
    }
  }
  return false
}

// Klickt ein Vinted-Katalog-Item per id="catalog-N" (goldener Selektor)
// KEIN scrollIntoView – Vinted schließt Dropdown bei Scroll-Events!
async function clickCatalogItem(text) {
  const items = document.querySelectorAll('[id^="catalog-"]:not(#catalog-search-input)')
  const target = text.toLowerCase().trim()

  // 1. Exakter Match
  for (const el of items) {
    const rect = el.getBoundingClientRect()
    if (rect.width === 0 || rect.height === 0) continue
    const t = (el.innerText || el.textContent || '').trim()
    if (t.toLowerCase() === target) {
      console.log('[ListSync] ✓ catalog-item exakt:', el.id, '"' + t + '"')
      fullClick(getClickTarget(el))
      await wait(1200)
      return true
    }
  }
  // 2. Startswith-Match
  for (const el of items) {
    const rect = el.getBoundingClientRect()
    if (rect.width === 0 || rect.height === 0) continue
    const t = (el.innerText || el.textContent || '').trim().toLowerCase()
    if (t.startsWith(target) || target.startsWith(t)) {
      console.log('[ListSync] ✓ catalog-item partial:', el.id, '"' + t + '"')
      fullClick(getClickTarget(el))
      await wait(1200)
      return true
    }
  }
  // Debug
  const visible = [...items]
    .filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 })
    .map(e => `${e.id}: "${(e.innerText||'').trim().substring(0,30)}"`)
  console.log('[ListSync] catalog-Items (kein Treffer für "' + text + '"):', visible)
  return false
}

// Findet den geöffneten Kategorie-Dropdown-Container
function getCatalogContainer() {
  // Suche den gemeinsamen Eltern-Container der catalog-N Items
  const item = document.querySelector('[id^="catalog-"]:not(#catalog-search-input)')
  if (item) {
    let p = item.parentElement
    while (p && p !== document.body) {
      const items = p.querySelectorAll('[id^="catalog-"]')
      if (items.length > 2) return p
      p = p.parentElement
    }
  }
  // Fallback: dialog, listbox oder bekannte Vinted-Klassen
  return document.querySelector(
    '[role="dialog"], [role="listbox"], ' +
    '[class*="catalog"], [class*="Catalog"], ' +
    '[class*="CategoryDropdown"], [class*="category-dropdown"]'
  )
}

// Gibt das tatsächlich klickbare Element zurück – bei Vinted haben <li>-Items
// oft einen inneren <div role="button"> als echten Klick-Target.
function getClickTarget(el) {
  if (['BUTTON', 'A'].includes(el.tagName) || el.getAttribute('role') === 'button') return el
  const inner = el.querySelector('[role="button"], button, a[href]')
  if (inner) return inner
  return el
}

// Findet und klickt das Element mit dem passendsten Text –
// NUR innerhalb des geöffneten Dropdowns, nie in der Navigation
async function findAndClickText(text, container) {
  const root = container || getCatalogContainer() || document.body
  const all = root.querySelectorAll(
    'li, ul > *, [role="option"], [role="menuitem"], [role="radio"], ' +
    'button, a, label, div[tabindex], span[tabindex], ' +
    '[role="button"], ' +
    '[class*="item"], [class*="Item"], [class*="option"], [class*="Option"], ' +
    '[class*="cell"], [class*="Cell"], [class*="row"], [class*="Row"]'
  )

  const candidates = []
  for (const el of all) {
    if (isInNav(el)) continue  // Navigation immer überspringen
    const rect = el.getBoundingClientRect()
    if (rect.width === 0 || rect.height === 0) continue
    const raw = (el.innerText || el.textContent || '').trim()
    if (!raw) continue
    const firstLine = raw.split('\n')[0].trim()
    const lower = firstLine.toLowerCase()
    const target = text.toLowerCase()

    if (firstLine === text) { candidates.push({ el, score: 1 }); continue }
    if (lower === target)   { candidates.push({ el, score: 2 }); continue }
    if (lower.startsWith(target + ' ') || lower.endsWith(' ' + target)) {
      candidates.push({ el, score: 3 }); continue
    }
    if (lower.includes(target) && firstLine.length < text.length + 30) {
      candidates.push({ el, score: 4 }); continue
    }
  }

  if (!candidates.length) {
    const visible = []
    for (const el of all) {
      const r = el.getBoundingClientRect()
      if (r.width > 0 && r.height > 0 && !isInNav(el)) {
        const t = (el.innerText || el.textContent || '').trim().substring(0, 40)
        if (t) visible.push(`${el.tagName}[role=${el.getAttribute('role')||''}]: "${t}"`)
      }
    }
    console.log('[ListSync] Kein Treffer für "' + text + '" in Container:', visible.slice(0, 20))
    return false
  }

  candidates.sort((a, b) => a.score - b.score)
  const { el } = candidates[0]
  // Klicke auf den echten Klick-Target (inner div[role=button] wenn vorhanden)
  const target = getClickTarget(el)
  console.log('[ListSync] Klicke:', target.tagName, '[role=' + (target.getAttribute('role')||'') + ']', '"' + (target.innerText || '').trim().substring(0, 30) + '"')
  fullClick(target)  // fullClick: alle Pointer+Mouse Events + reactClick
  await wait(1200)
  return true
}

// Wartet bis catalog-N Items sichtbar sind (Kategorie-Dropdown)
async function waitForCatalogItems(timeout = 6000) {
  return new Promise(resolve => {
    const check = () => {
      const items = document.querySelectorAll('[id^="catalog-"]:not(#catalog-search-input)')
      return [...items].some(e => {
        const r = e.getBoundingClientRect()
        return r.width > 0 && r.height > 0
      })
    }
    if (check()) return resolve(true)
    const ob = new MutationObserver(() => { if (check()) { ob.disconnect(); resolve(true) } })
    ob.observe(document.body, { childList: true, subtree: true })
    setTimeout(() => { ob.disconnect(); resolve(false) }, timeout)
  })
}

// Wartet bis IRGENDEIN Panel geöffnet ist (catalog-N, condition-N, input-dropdown li…)
async function waitForAnyPanelItems(timeout = 6000) {
  return new Promise(resolve => {
    const check = () => {
      // catalog-N (Kategorie)
      const cats = [...document.querySelectorAll('[id^="catalog-"]:not(#catalog-search-input)')]
      if (cats.some(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 })) return true
      // condition-N (Zustand)
      const conds = [...document.querySelectorAll('[data-testid^="condition-"]')]
      if (conds.some(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 })) return true
      // input-dropdown Panel (Größe, Farbe, Material) – li Items im input-dropdown__content
      const dropLis = [...document.querySelectorAll('[class*="input-dropdown__content"] li, [class*="input-dropdown"] li')]
        .filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 })
      if (dropLis.length > 0) return true
      // Generisch: role="option" in Dialog
      const opts = [...document.querySelectorAll('[role="dialog"] [role="option"], [role="listbox"] [role="option"]')]
      if (opts.some(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 })) return true
      return false
    }
    if (check()) return resolve(true)
    const ob = new MutationObserver(() => { if (check()) { ob.disconnect(); resolve(true) } })
    ob.observe(document.body, { childList: true, subtree: true })
    setTimeout(() => { ob.disconnect(); resolve(false) }, timeout)
  })
}

// Findet den geöffneten Panel-Container (catalog-N, condition-N, input-dropdown, dialog)
function getAnyOpenPanel() {
  // 1. input-dropdown Panel (Größe, Farbe, Material) — hat testid="*-dropdown-content"
  const dropdown = [...document.querySelectorAll('[class*="input-dropdown"]')]
    .find(e => {
      const r = e.getBoundingClientRect()
      return r.width > 0 && r.height > 0 && e.querySelector('li')
    })
  if (dropdown) return dropdown

  // 2. catalog-N sichtbar? (Kategorie)
  const catItem = [...document.querySelectorAll('[id^="catalog-"]:not(#catalog-search-input)')]
    .find(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 })
  if (catItem) return getCatalogContainer()

  // 3. condition-N sichtbar? (Zustand)
  const condItem = [...document.querySelectorAll('[data-testid^="condition-"]')]
    .find(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 })
  if (condItem) {
    let p = condItem.parentElement
    while (p && p !== document.body) {
      if (p.querySelectorAll('[data-testid^="condition-"]').length > 1) return p
      p = p.parentElement
    }
    return condItem.parentElement
  }

  // 4. Generisch: sichtbarer Dialog / Overlay
  for (const sel of ['[role="dialog"]', '[role="listbox"]', '[class*="overlay"]', '[class*="Overlay"]']) {
    const el = document.querySelector(sel)
    if (el) {
      const r = el.getBoundingClientRect()
      if (r.width > 0 && r.height > 0) return el
    }
  }

  return null
}

// Klickt condition-N item das den Text enthält (für Zustand-Panel)
async function clickConditionItem(text) {
  const target = text.toLowerCase().trim()
  const items = [...document.querySelectorAll('[data-testid^="condition-"]')]
    .filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 })

  // Exakter Match
  for (const el of items) {
    const t = (el.innerText || el.textContent || '').trim()
    if (t.toLowerCase() === target) {
      console.log('[ListSync] ✓ condition-item exakt:', el.dataset.testid, '"' + t + '"')
      fullClick(getClickTarget(el)); await wait(800); return true
    }
  }
  // Partial Match
  for (const el of items) {
    const t = (el.innerText || el.textContent || '').trim().toLowerCase()
    if (t.includes(target) || target.includes(t.split('\n')[0])) {
      console.log('[ListSync] ✓ condition-item partial:', el.dataset.testid, '"' + t + '"')
      fullClick(getClickTarget(el)); await wait(800); return true
    }
  }
  const debug = items.map(e => `${e.dataset.testid}: "${(e.innerText||'').trim().substring(0,30)}"`)
  console.log('[ListSync] condition-Items (kein Treffer für "' + text + '"):', debug)
  return false
}

// Prüft ob ein Element Teil der Vinted-Navigation ist (nicht das Formular)
function isInNav(el) {
  let p = el
  while (p && p !== document.body) {
    if (['NAV', 'HEADER'].includes(p.tagName)) return true
    const cls = typeof p.className === 'string' ? p.className : ''
    if (/\b(nav|navbar|topbar|header|navigation|menu-bar)\b/i.test(cls)) return true
    if (p.getAttribute && p.getAttribute('role') === 'navigation') return true
    p = p.parentElement
  }
  return false
}

// ── Kategorie-Auswahl: hierarchisch durchklicken ─────────────────────────────
// "Herren – Kleidung – Pullover & Sweater – Pullis & Hoodies"
// → splittet zu ["Herren","Kleidung","Pullover & Sweater","Pullis & Hoodies"]
// → klickt jede Ebene nacheinander durch (kein CATEGORY_MAP nötig)

async function fillCategory(category) {
  if (!category || category === 'Sonstiges') return false

  // Pfad direkt aus dem Kategorie-String ableiten
  const path = category.split(' – ').map(s => s.trim()).filter(Boolean)
  if (!path.length) return false

  try {
    // Dropdown-Trigger finden – NUR das Formularfeld, nicht die Navigation!
    let trigger = null

    // 1. DIREKT per ID/data-testid (live getestet auf vinted.de/items/new)
    trigger = document.querySelector('input#category, [data-testid="catalog-select-dropdown-input"]')
    if (trigger && isInNav(trigger)) trigger = null

    // 2. Placeholder-Text (falls Vinted die ID ändert)
    if (!trigger) {
      trigger = document.querySelector('input[placeholder="Wähle eine Kategorie"]')
      if (trigger && isInNav(trigger)) trigger = null
    }

    // 3. Letzter Fallback: Klick-Element das "Kategorie" enthält, aber NICHT in der Nav
    if (!trigger) {
      for (const el of document.querySelectorAll('button, [role="button"], [role="combobox"]')) {
        if (!isInNav(el) && (el.innerText || el.textContent || '').includes('Kategorie')) {
          trigger = el; break
        }
      }
    }

    if (!trigger) { console.warn('[ListSync] Kategorie-Trigger nicht gefunden'); return false }

    fullClick(trigger)   // KEIN scrollIntoView – schließt Dropdown bei Scroll!

    // Warten bis der Dropdown wirklich sichtbar ist
    setStatus('Warte auf Kategorie-Dropdown…')
    const catalogReady = await waitForCatalogItems(6000)
    if (!catalogReady) { console.warn('[ListSync] Kategorie-Dropdown nicht geladen'); return false }
    await wait(400)

    // Hierarchisch durch alle Pfad-Ebenen klicken
    for (const step of path) {
      setStatus(`Kategorie: ${step}…`)
      await wait(500)

      // 1. Versuch: catalog-N IDs (goldener Selektor für Vinted)
      let found = await clickCatalogItem(step)

      // 2. Fallback: Suche NUR im geöffneten Dropdown-Container
      if (!found) {
        console.warn('[ListSync] catalog-item fehlgeschlagen, suche im Container:', step)
        const container = getCatalogContainer()
        found = await findAndClickText(step, container)
      }

      if (!found) {
        console.warn('[ListSync] Kategorie-Schritt nicht gefunden:', step)
        return false
      }

      // Warten bis nächste Ebene erscheint
      await wait(1200)
    }

    setStatus('✓ Kategorie')
    return true
  } catch(e) {
    console.warn('[ListSync] Kategorie Fehler:', e.message)
    return false
  }
}

// ── Universelle Feld-Ausfüll-Funktion ────────────────────────────────────────

// Füllt ein Feld egal ob Input, Select, Radio, Klick-Karte oder Autocomplete
async function fillAny(labelTexts, value, name) {
  if (!value) return false
  const labels = Array.isArray(labelTexts) ? labelTexts : [labelTexts]

  // 1. Input/Textarea per Label finden
  for (const labelText of labels) {
    const el = findByLabel(labelText)
    if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' })
      el.focus()
      setNativeValue(el, value)
      await wait(400)
      // Dropdown-Option klicken falls autocomplete
      const opt = document.querySelector('[role="option"]:not([aria-disabled="true"])')
      if (opt && opt.offsetParent !== null) { opt.click(); await wait(400) }
      setStatus('✓ ' + name)
      return true
    }
  }

  // 2. Radio-Buttons / Klick-Karten mit passendem Text
  const clickables = document.querySelectorAll(
    '[role="radio"], [role="option"], [role="button"], label, button, [class*="Chip"], [class*="chip"], [class*="tag"], [class*="Tag"]'
  )
  for (const el of clickables) {
    if (el.offsetParent !== null && el.textContent.trim().toLowerCase() === value.toLowerCase()) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' })
      await wait(200)
      reactClick(el)
      await wait(500)
      setStatus('✓ ' + name)
      return true
    }
  }

  // 3. Native select
  for (const sel of document.querySelectorAll('select')) {
    for (const opt of sel.options) {
      if (opt.text.toLowerCase().includes(value.toLowerCase())) {
        setNativeValue(sel, opt.value)
        await wait(300)
        setStatus('✓ ' + name)
        return true
      }
    }
  }

  // 4. Dropdown öffnen und Option wählen (falls noch geschlossen)
  for (const labelText of labels) {
    try {
      const result = document.evaluate(
        `//*[contains(normalize-space(text()),"${labelText}")]`,
        document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
      )
      const trigger = result.singleNodeValue
      if (trigger && trigger.offsetParent !== null) {
        reactClick(trigger)
        await wait(800)
        const found = await clickOption(value)
        if (found) { setStatus('✓ ' + name); return true }
      }
    } catch {}
  }

  console.warn('[ListSync] Feld nicht gefunden:', name)
  return false
}

// ── Vinted Attribut-Felder gezielt ausfüllen ────────────────────────────────
// Nutzt die bekannten data-testid Selektoren von vinted.de/items/new

async function clickVintedField(testid, value, name, opts = {}) {
  if (!value) return false

  // 1. Trigger-Input finden (readonly, öffnet Panel bei Klick)
  const trigger = document.querySelector(`[data-testid="${testid}"]`)
  if (!trigger) { console.warn('[ListSync] Kein Trigger gefunden:', testid); return false }

  console.log('[ListSync] Klicke Feld:', testid, '→', value)
  fullClick(trigger)
  await wait(1500)

  // 2. Marke: Autocomplete-Suche (Panel öffnet sich mit eigenem Search-Input)
  if (opts.autocomplete) {
    const searchSels = [
      '[data-testid="brand-search--input"]',       // korrekte testid (live getestet)
      '[data-testid*="brand"][data-testid*="input"]',
      '[class*="input-dropdown"] input:not([readonly]):not([type="hidden"])',
      '[class*="input-dropdown__content"] input:not([readonly])',
    ]
    let searchInput = null
    for (let attempt = 0; attempt < 12; attempt++) {
      for (const s of searchSels) {
        const el = document.querySelector(s)
        if (el && el.offsetParent !== null && !el.readOnly) { searchInput = el; break }
      }
      if (searchInput) break
      await wait(300)
    }
    if (!searchInput) {
      console.warn('[ListSync] Marke-Autocomplete: kein Search-Input gefunden')
      return false
    }
    searchInput.focus()
    setNativeValue(searchInput, value)
    await wait(2000)

    // Suchergebnisse: <li> mit innerem [role="button"] — exakt wie Größe/Farbe
    const dropLis = [...document.querySelectorAll('[class*="input-dropdown"] li')]
      .filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 })

    const target = value.toLowerCase().trim()
    // Exakter Match zuerst, dann startsWith
    const match = dropLis.find(e => e.textContent.trim().toLowerCase() === target)
      || dropLis.find(e => e.textContent.trim().toLowerCase().startsWith(target))
      || dropLis[0]  // Fallback: erster Treffer

    if (match) {
      console.log('[ListSync] ✓ Marke gefunden:', match.textContent.trim())
      fullClick(getClickTarget(match))
      await wait(700)
      setStatus('✓ ' + name)
      return true
    }
    console.warn('[ListSync] Marke: kein Suchergebnis für:', value)
    return false
  }

  // 3. Warte bis IRGENDEIN Panel sichtbar ist (catalog-N, condition-N, dialog…)
  const ready = await waitForAnyPanelItems(6000)
  if (!ready) {
    console.warn('[ListSync] Kein Panel geöffnet für:', name)
    return false
  }
  await wait(400)

  // 4a. Zustand: condition-N Items
  const condItems = [...document.querySelectorAll('[data-testid^="condition-"]')]
    .filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 })
  if (condItems.length > 0) {
    const found = await clickConditionItem(value)
    if (found) { setStatus('✓ ' + name); return true }
  }

  // 4b. Material: material-N Items (data-testid="material-{id}")
  const matItems = [...document.querySelectorAll('[data-testid^="material-"]:not([data-testid$="--title"]):not([data-testid$="--suffix"]):not([data-testid$="-checkbox"])')]
    .filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 })
  if (matItems.length > 0) {
    const target = value.toLowerCase().trim()
    const match = matItems.find(e => e.textContent.trim().toLowerCase() === target)
      || matItems.find(e => e.textContent.trim().toLowerCase().includes(target))
    if (match) {
      console.log('[ListSync] ✓ material-item:', match.dataset.testid, '"' + match.textContent.trim() + '"')
      fullClick(getClickTarget(match))
      await wait(800)
      setStatus('✓ ' + name)
      return true
    }
    console.warn('[ListSync] Material: kein Treffer für:', value, '| Verfügbar:', matItems.slice(0,8).map(e=>e.textContent.trim()).join(', '))
  }

  // 4c. catalog-N Items (Größe, Farbe)
  let found = await clickCatalogItem(value)

  // 4d. Generischer Fallback: Text-Suche im offenen Panel
  if (!found) {
    const container = getAnyOpenPanel() || getCatalogContainer()
    found = await findAndClickText(value, container)
  }

  if (found) {
    await wait(600)
    setStatus('✓ ' + name)
    return true
  }

  console.warn('[ListSync] Kein Treffer im Panel für:', name, '=', value)
  return false
}

// ── Main ──────────────────────────────────────────────────────────────────────

// Wartet bis ein neues Feld nach Kategorie-Auswahl sichtbar wird
async function waitForAttributeFields(timeout = 8000) {
  const fieldSels = [
    'input[placeholder*="Marke"]', 'input[placeholder*="brand"]',
    'input[placeholder*="Größe"]', 'input[placeholder*="size"]',
    '[data-testid*="brand"]', '[data-testid*="size"]',
    '[data-testid*="condition"]', 'select[name*="condition"]',
    '[role="radio"]', '[class*="Chip"]', '[class*="chip"]',
  ]
  return new Promise(resolve => {
    const check = () => {
      for (const s of fieldSels) {
        if (document.querySelector(s)) return true
      }
      return false
    }
    if (check()) return resolve(true)
    const ob = new MutationObserver(() => { if (check()) { ob.disconnect(); resolve(true) } })
    ob.observe(document.body, { childList: true, subtree: true })
    setTimeout(() => { ob.disconnect(); resolve(false) }, timeout)
  })
}

async function fill() {
  await wait(2500) // Vinted React braucht Zeit zum Booten

  const listing = await getListing()
  if (!listing) return

  const { activeVintedAccount } = await new Promise(r => chrome.storage.local.get('activeVintedAccount', r))
  showBanner(listing, activeVintedAccount)
  setStatus('Starte…')
  await wait(500)

  // ── 1. Basis-Felder (immer sichtbar) ─────────────────────────────────────

  await fillField([
    'input[data-testid="item-title-input"]', 'input[data-testid="title"]',
    'input#title', 'input[name="title"]',
    'input[placeholder*="Titel"]', 'input[placeholder*="Name des Artikels"]',
  ], listing.title.substring(0, 60), 'titel', 'Titel')
  await wait(400)

  await fillField([
    'textarea[data-testid="item-description-input"]', 'textarea[data-testid="description"]',
    'textarea#description', 'textarea[name="description"]',
    'textarea[placeholder*="Beschreibung"]', 'textarea[placeholder*="Artikelbeschreibung"]',
  ], listing.description || listing.title, 'beschreibung', 'Beschreibung')
  await wait(400)

  await fillField([
    'input[data-testid="item-price-input"]', 'input[data-testid="price"]',
    'input#price', 'input[name="price"]',
    'input[placeholder*="Preis"]', 'input[type="number"]',
  ], String(listing.price).replace('.', ','), 'preis', 'Preis')
  await wait(400)

  // ── 2. Kategorie auswählen (öffnet weitere Felder) ───────────────────────

  if (listing.category && listing.category !== 'Sonstiges') {
    setStatus('Kategorie wird ausgewählt…')
    await fillCategory(listing.category)
    // Warten bis die neuen Felder erscheinen
    setStatus('Warte auf Attribut-Felder…')
    await waitForAttributeFields(8000)
    await wait(800)
  }

  // ── DEBUG: alle sichtbaren Formular-Elemente ausgeben ────────────────────
  const debugFields = []
  document.querySelectorAll('input, textarea, select, [role="radio"], [role="combobox"], [role="listbox"]').forEach(el => {
    if (el.offsetParent !== null) {
      debugFields.push({
        tag: el.tagName,
        type: el.type || el.getAttribute('role') || '',
        name: el.name || el.id || '',
        placeholder: el.placeholder || '',
        value: el.value || el.textContent?.trim()?.substring(0, 50) || '',
        testid: el.dataset?.testid || '',
        class: el.className?.substring(0, 60) || '',
      })
    }
  })
  console.log('[ListSync DEBUG] Sichtbare Felder nach Kategorie:', JSON.stringify(debugFields, null, 2))
  // ─────────────────────────────────────────────────────────────────────────

  // ── 3. Felder die nach Kategorie erscheinen ───────────────────────────────────

  // Zustand – data-testid: category-condition-single-list-input
  // Vinted nutzt: "Neu, mit Etikett", "Neu, ohne Etikett", "Sehr gut", "Gut", "Befriedigend"
  if (listing.condition) {
    const condMap = {
      'Neu mit Etikett':  'Neu, mit Etikett',
      'Neu, mit Etikett': 'Neu, mit Etikett',
      'Neu ohne Etikett': 'Neu, ohne Etikett',
      'Neu, ohne Etikett':'Neu, ohne Etikett',
      'Neu':              'Neu, mit Etikett',
      'Sehr gut':         'Sehr gut',
      'Gut':              'Gut',
      'Befriedigend':     'Befriedigend',
      'Stark getragen':   'Stark getragen',
    }
    const condValue = condMap[listing.condition] || listing.condition
    setStatus('Zustand wird gesetzt…')
    await clickVintedField('category-condition-single-list-input', condValue, 'Zustand')
    await wait(600)
  }

  // Größe – data-testid: size-select-dropdown-input
  if (listing.size) {
    setStatus('Größe wird gesetzt…')
    await clickVintedField('size-select-dropdown-input', listing.size, 'Größe')
    await wait(600)
  }

  // Marke – data-testid: brand-select-dropdown-input (öffnet Autocomplete-Panel)
  if (listing.brand) {
    setStatus('Marke wird gesetzt…')
    await clickVintedField('brand-select-dropdown-input', listing.brand, 'Marke', { autocomplete: true })
    await wait(700)
  }

  // Farbe – data-testid: color-select-dropdown-input
  if (listing.color) {
    setStatus('Farbe wird gesetzt…')
    await clickVintedField('color-select-dropdown-input', listing.color, 'Farbe')
    await wait(600)
  }

  // Material – data-testid: category-material-multi-list-input
  if (listing.material) {
    setStatus('Material wird gesetzt…')
    await clickVintedField('category-material-multi-list-input', listing.material, 'Material')
    await wait(600)
  }

  // Versand – Standard Vinted-Versand auswählen
  setStatus('Versand wird gesetzt…')
  await fillAny(['Versand', 'Versandoptionen', 'Shipping'], 'Vinted-Versand', 'Versand')
  await wait(400)

  setStatus('✅ Felder fertig – Bilder werden geladen…')
  await injectImages()
  await wait(1500)
  setStatus('✅ Fertig! Bitte prüfen und absenden.', true)
  await chrome.storage.local.remove('pendingListing')
}

// ── Bilder injizieren ─────────────────────────────────────────────────────────
// Läuft NACH fill() – dann ist das Formular garantiert bereit.
// Liest imageData aus pendingListing (vorher von background.js geladen).
async function injectImages() {
  const { pendingListing } = await new Promise(r => chrome.storage.local.get('pendingListing', r))
  const imageData = pendingListing?.imageData
  if (!imageData?.length) { console.log('[ListSync] Keine Bilder zum Hochladen'); return }

  console.log('[ListSync] Starte Bild-Injection:', imageData.length, 'Bilder')

  // File-Input finden (mit Retry – React könnte noch mounten)
  let fi = null
  for (let attempt = 0; attempt < 15; attempt++) {
    fi = document.querySelector('[data-testid="add-photos-input"]')
      || document.querySelector('input[type="file"][accept*="image"]')
      || document.querySelector('input[type="file"][name="photos"]')
    if (fi) break
    await wait(800)
  }
  if (!fi) { console.warn('[ListSync] File-Input nicht gefunden'); return }

  // DataTransfer mit allen Bildern aufbauen
  const dt = new DataTransfer()
  for (let i = 0; i < imageData.length; i++) {
    try {
      const { base64, type } = imageData[i]
      const [, d] = base64.split(',')
      const bin = atob(d)
      const arr = new Uint8Array(bin.length)
      for (let j = 0; j < bin.length; j++) arr[j] = bin.charCodeAt(j)
      const ext = (type || 'image/jpeg').split('/')[1] || 'jpg'
      dt.items.add(new File([arr], `photo_${i + 1}.${ext}`, { type: type || 'image/jpeg' }))
    } catch(e) { console.warn('[ListSync] Bild-Konvertierung fehlgeschlagen:', i, e.message) }
  }
  if (!dt.files.length) { console.warn('[ListSync] Keine Dateien in DataTransfer'); return }

  // files-Property überschreiben (React liest event.target.files)
  Object.defineProperty(fi, 'files', { get: () => dt.files, configurable: true })

  const files = Array.from(dt.files)

  // Strategie 1: onUploadFilesStart (Vinreds interner Upload-Handler – zuverlässigster Weg)
  const fk = Object.keys(fi).find(k =>
    k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance')
  )
  let triggered = false
  if (fk) {
    let node = fi[fk]
    let tries = 0
    while (node && tries++ < 40) {
      const props = node?.memoizedProps || node?.pendingProps
      if (props && typeof props.onUploadFilesStart === 'function') {
        try {
          props.onUploadFilesStart(files)
          triggered = true
          console.log('[ListSync] ✓ Bilder via onUploadFilesStart –', files.length, 'Bilder')
          break
        } catch(e) { console.warn('[ListSync] onUploadFilesStart Fehler:', e.message); break }
      }
      node = node.return
    }
  }

  // Strategie 2: onChange mit files auf dem Input (Fallback)
  if (!triggered && fk) {
    Object.defineProperty(fi, 'files', { get: () => dt.files, configurable: true })
    let node = fi[fk]
    let tries = 0
    while (node && tries++ < 40) {
      const props = node?.memoizedProps || node?.pendingProps
      const handler = props?.onChange
      if (handler) {
        try {
          handler({
            target: fi, currentTarget: fi,
            preventDefault: () => {}, stopPropagation: () => {},
            persist: () => {}, nativeEvent: new Event('change', { bubbles: true })
          })
          triggered = true
          console.log('[ListSync] ✓ Bilder via onChange –', files.length, 'Bilder')
          break
        } catch(e) { console.warn('[ListSync] onChange Fehler:', e.message); break }
      }
      node = node.return
    }
  }

  // Strategie 3: native Events (letzter Fallback)
  if (!triggered) {
    Object.defineProperty(fi, 'files', { get: () => dt.files, configurable: true })
    fi.dispatchEvent(new Event('change', { bubbles: true }))
    fi.dispatchEvent(new Event('input',  { bubbles: true }))
    console.log('[ListSync] Bilder via native Event –', files.length, 'Bilder')
  }

  setStatus(`📸 ${dt.files.length} Bilder werden hochgeladen…`)
  await wait(3000)  // Zeit für Vinted-Upload
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', fill)
} else {
  fill()
}
